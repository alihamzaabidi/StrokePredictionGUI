import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from pymongo import MongoClient

# Connect to the MongoDB server
client = MongoClient('mongodb+srv://SyedAliHamza:Msadafh1@cluster0.epbn4z5.mongodb.net/')

# Access the database and collection
db = client['Assessment_Data']
collection = db['Stroke_Prediction']

# Retrieve data from MongoDB and convert it to a DataFrame, excluding the '_id' column
data = list(collection.find({}, {"_id": 0}))

stroke_data = pd.DataFrame(data)

# Check for missing values
stroke_data.isnull().sum()

# Let's explore the relationship between different attributes
sns.scatterplot(x='age', y='bmi', data=stroke_data)
sns.barplot(x='sex', y='heart_disease', data=stroke_data)
sns.barplot(x='stroke', y='hypertension', data=stroke_data)

# Now the process of Train and Test, then Split
x = stroke_data.drop(['stroke'], axis=1)
y = stroke_data['stroke']

xtrain, xtest, ytrain, ytest = train_test_split(x, y, test_size=0.2, random_state=42)

# Scale the features
sc = StandardScaler()
xtrain = sc.fit_transform(xtrain)
xtest = sc.transform(xtest)

# Train the Logistic Regression model
lr = LogisticRegression()
lr.fit(xtrain, ytrain)
score_lr = lr.score(xtest, ytest)

# Train the Support Vector Machine (SVM) model
sv = SVC()
sv.fit(xtrain, ytrain)
score_sv = sv.score(xtest, ytest)

# Train the K-Nearest Neighbors (KNN) model
kn = KNeighborsClassifier(n_neighbors=10)
kn.fit(xtrain, ytrain)
score_kn = kn.score(xtest, ytest)

# Print the scores of the models
print("Logistic Regression Score:", score_lr)
print("SVM Score:", score_sv)
print("K-Nearest Neighbors Score:", score_kn)

# Display the first row of the DataFrame
stroke_data.head(1)

# As an example, use 'a' list to test the KNN model
a = np.array([[1, 63, 0, 1, 1, 4, 1, 228.69, 36.6, 1]])
prediction_kn = kn.predict(a)

def prediction():
    if prediction_kn[0] == 1:
        print("Chances of stroke are high")
    else:
        print("Chances of stroke are low")

prediction()
